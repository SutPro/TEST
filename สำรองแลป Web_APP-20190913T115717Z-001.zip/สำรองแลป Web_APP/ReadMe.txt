﻿!!! ไฟล์แลปนี้มีไว้เพื่อใช้ในการเรียนแลปปฏิบัติการเท่านั้น หากพบว่านำมาส่งเป็นการบ้านขออนุญาตแจ้งทุจริตไปยังผู้สอนในรายวิชา !!!

กรณีเจอปัญหารันแล้วขึ้น
Unable to start debugging. The startup project could not be launched. 

ให้ลบไฟล์ CurrentSettings.vssettings
โดยสามารถเข้าไปลบไฟล์ได้ที่ 
Documents\Visual Studio 2015\Settings